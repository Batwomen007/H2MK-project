package com.banking;

public class MainApp {
    public static void main(String[] args) {
        System.out.println("Banking Management System UI Project");
        System.out.println("You can find the HTML files in /src/main/resources/static/");
    }
}